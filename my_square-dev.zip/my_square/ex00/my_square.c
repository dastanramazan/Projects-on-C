
#include <stdlib.h>
#include <stdio.h>

void my_square (int x, int y) {

    for (int i = 1; i <= x; i++) { // проходим по строкам x
        for (int j = 1; j <= y; j++) { // проходим по колоннам y
           if (i == 1 || i == x) { // первая и последняя в строке
               if (j == 1 || j == y){ // первая и последняя в колонне
               printf("o"); // печатаем о
               }
           
           else {
               printf("-"); // иначе печатаем между первой и последней коллонной первого и последнего строки
           }
           }
           else if (j == 1 || j == y) { // первая и последняя колонна
               printf("|"); // печатаем
           }
          else {
              printf(" "); // оставляем пробелы
          }
        }
        printf("\n");
    }
    
}

int main(int ac, char **av) {
    if (ac != 3) { // входящие значения у нас три av 0, 1, 2. если их не три, то возвращем 0
     return 0;
    }
    int rows = atoi(av[1]);
    int columns = atoi(av[2]);
    
    my_square(rows, columns);
    
   
return 0;
}